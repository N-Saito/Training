package application;

import java.net.MalformedURLException;

import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import controller.ViewController;
import controller.ViewController2;

public class Main extends Application {

	private static Main instance;

	private Stage primaryStage;

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {
		try {
			instance = this;
			this.primaryStage = primaryStage;
			this.primaryStage.setWidth(800);
			this.primaryStage.setHeight(600);
			// �y�[�W1�ɑJ��
			sendPage1Controller();
			this.primaryStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void sendPage1Controller() throws MalformedURLException {
		primaryStage.setTitle("Page1");
		ViewController controller = new ViewController();
		this.replaceSceneContent(controller);
	}

	/**
	 * Page1�֑J�ڂ���
	 * 
	 * @param labelText
	 * @throws MalformedURLException
	 */
	public void sendPage2Controller() throws MalformedURLException {
		primaryStage.setTitle("Page2");
		ViewController2 controller = new ViewController2();
		this.replaceSceneContent(controller);
	}

	/**
	 * �V�[���̕ύX
	 * 
	 * @param controller
	 */
	private void replaceSceneContent(Parent controller) {
		Scene scene = primaryStage.getScene();
		if (scene == null) {
			scene = new Scene(controller);
			primaryStage.setScene(scene);
		} else {
			primaryStage.getScene().setRoot(controller);
		}
	}

	public static Main getInstance() {
		return instance;
	}

	public Stage getPrimaryStage() {
		return primaryStage;
	}
}
