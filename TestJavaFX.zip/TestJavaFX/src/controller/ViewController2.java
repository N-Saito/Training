package controller;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.GridPane;
import application.Main;

public class ViewController2 extends GridPane implements Initializable {

	public ViewController2() throws MalformedURLException {
		File viewFile = new File("src\\view\\View2.fxml");
		URL url = viewFile.toURI().toURL();
		FXMLLoader fxmlLoader = new FXMLLoader(url);
		fxmlLoader.setRoot(this);

		// �������g���R���g���[���Ƃ��Đݒ�
		fxmlLoader.setController(this);

		try {
			fxmlLoader.load();
		} catch (IOException exception) {
			throw new RuntimeException(exception);
		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// button = new Button();
	}

	@FXML
	public void back(ActionEvent e) throws MalformedURLException {
		Main.getInstance().sendPage1Controller();
	}
}
