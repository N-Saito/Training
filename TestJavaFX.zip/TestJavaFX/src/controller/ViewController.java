package controller;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import application.Main;

public class ViewController extends TabPane implements Initializable {

	/* ���{xml�̎Q�ƃ{�^�� */
	@FXML
	Button sansyo_button = new Button();

	/* SR���{xml�̎Q�ƃ{�^�� */
	@FXML
	Button sansyo_button2 = new Button();

	@FXML
	TextField textField = new TextField();

	@FXML
	ListView<String> listView = new ListView();

	public ViewController() throws MalformedURLException {
		File viewFile = new File("src\\view\\View.fxml");
		URL url = viewFile.toURI().toURL();
		FXMLLoader fxmlLoader = new FXMLLoader(url);
		fxmlLoader.setRoot(this);
		fxmlLoader.setController(this);

		try {
			fxmlLoader.load();
		} catch (IOException exception) {
			throw new RuntimeException(exception);
		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		final FileChooser fc = new FileChooser();
		sansyo_button.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				File importFile = fc.showOpenDialog(Main.getInstance()
						.getPrimaryStage());
				if (importFile != null) {
					textField.setText(importFile.getPath().toString());
				}
			}
		});

		sansyo_button2.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				List<File> importFiles = fc.showOpenMultipleDialog(Main
						.getInstance().getPrimaryStage());
				ObservableList<String> listRecords = FXCollections
						.observableArrayList();
				if (importFiles != null) {
					for (File file : importFiles) {
						listRecords.add(file.getAbsolutePath());
					}
					listView.setItems(listRecords);
				}
			}
		});
	}

	@FXML
	public void pressed(ActionEvent e) {
		System.out.println(((Button) e.getSource()).getText() + " pressed");
	}

	@FXML
	public void next(ActionEvent e) throws MalformedURLException {
		Main.getInstance().sendPage2Controller();
	}
}
